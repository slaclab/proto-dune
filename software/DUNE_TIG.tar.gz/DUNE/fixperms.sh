#!/bin/sh

chgrp -R lbnedaq /u1/DUNE
chmod -R g+rswX  /u1/DUNE


