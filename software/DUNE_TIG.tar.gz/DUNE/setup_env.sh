source /afs/slac/g/reseng/python/2.7.13/settings.sh
source /afs/slac/g/reseng/boost/1.53.0_p2/settings.sh
source /afs/slac/g/reseng/xilinx/vivado_2016.4/Vivado/2016.4/settings64.sh
export LD_LIBRARY_PATH=/opt/cactus/lib:$LD_LIBRARY_PATH
#kinit lruckman@CERN.CH
